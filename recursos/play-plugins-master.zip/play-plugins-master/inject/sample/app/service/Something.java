package service;

public interface Something {

  public String noWhat();

}